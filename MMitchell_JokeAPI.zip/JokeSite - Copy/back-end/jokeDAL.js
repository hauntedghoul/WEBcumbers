// this will be a DAL module that exposes functions for CRUD
// and knows how to interact with the database
const {mongoose, Schema} = require('mongoose')

//setup mongoose and have it connect, etc...
const connectionString = "mongodb://127.0.0.1:27017/Jokes";
mongoose.connect(connectionString, {useUnifiedTopology: true, useNewUrlParser: true});
const connection = mongoose.connection;


connection.once("open", () => {
    console.log("Mongoose successfully connected")
})
//Setup my schemas and models
const joke = new Schema(
    {
        jokeId: Schema.Types.ObjectId,
        question: String,
        punchline: String,
        category: String
    },
    {collection: "category"}
);

const jokesCollection = mongoose.model("category", joke);

//Setup my schemas and models
exports.DAL = {
    getAllJokes: async function() {
        // const results = await jokesCollection.find({}).exec;
        // console.log(results);
            const jokes = await jokesCollection.find();
            return jokes;
    },
    jokeLimit: async function(count){
        const query = {};
        const sorting = {length: -1};

        const stuff = await jokesCollection.find(query).sort(sorting).limit(count);
        return stuff;
    },
    createJoke: async function(question, punchline, category){
        //use mongoose to create a new joke using the params passed
        const newJoke = new jokesCollection({
            jokeId: new mongoose.Types.ObjectId,
            question: question,
            punchline: punchline,
            category: category
        });
        const savedJoke = await newJoke.save();
        console.log("New joke saved to database:", savedJoke);
        return savedJoke;
    }
};

function initialJokes(){
    var initialJokes = [
        {jokeId: new mongoose.Types.ObjectId, question: "Two goldfish are in a tank. One says to the other, ", punchline: "Do you know how to drive this thing?", category: "military" },
        {jokeId: new mongoose.Types.ObjectId, question: "I'm afraid for the calendar", punchline: "Its days are numbered", category: "dad" },
        {jokeId: new mongoose.Types.ObjectId, question: "What do you call a factory that makes okay products?", punchline: "A satisfactory.", category: "dad" },
        {jokeId: new mongoose.Types.ObjectId, question: "Did you hear about the man who was hospitalized with six plastic horses inside him?", punchline: "The doctor described his condition as stable.", category: "horse" }
    ]
    jokesCollection.insertMany(initialJokes);
};

// initialJokes();