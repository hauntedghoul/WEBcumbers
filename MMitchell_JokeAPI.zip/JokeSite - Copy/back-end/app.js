const express = require("express");
const dal = require('./jokeDAL').DAL;

const port = 5004;

const app = express();

//to get forms working
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.get("/", (req, res) => {
    let myResponse = {
        Message: "Welcome to my API. Try out other routes!"
    };

    res.json(myResponse);
});

app.get("/jokes", async (req, res) => {
      const jokes = await dal.getAllJokes();
      res.json(jokes);
      console.log(jokes)
  });

  app.get("/jokes/:count", async (req, res) => {
    console.log(req.params.count);
    let results = await dal.jokeLimit(req.params.count);
    res.json(results);  
  })
app.post("/joke/create", async (req,res) => {
    const {question, punchline, category} = req.body;

    if (!question || !punchline || !category) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      try{
        await dal.createJoke(question, punchline, category);
        res.json({Message: "Joke created successfully"});
      } catch (err){
        res.status(500).json({error: err.message})
      }
});

app.listen(port, () => {
    console.log("express api running on port: " + port);
});

