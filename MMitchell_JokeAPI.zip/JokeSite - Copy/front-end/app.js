console.log("working");

const express = require("express");
const pug = require("pug");

const port = 5003;

const app = express();
app.use(express.static('public'));
//to get forms working
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.set("view engine", "pug");

app.get("/jokes", async (req, res) => {
    let jokesUrl = "http://localhost:5004/jokes";
    let result = await fetch(jokesUrl);
    let jokes = await result.json();
    console.log(jokes);
    let model = {
        jokeArray: jokes
    }
    res.render("jokes", model);
    
  });
 
app.get("/jokes/:count", async (req,res) =>{
    const count = parseInt(req.params.count);
    let jokesUrl = `http://localhost:5004/jokes/${count}`;
    console.log(jokesUrl);
    let result = await fetch(jokesUrl);
    let jokes = await result.json();
    console.log("jokes", jokes)

    let model = {
        jokeArray: jokes
    }
    res.render("jokes", model);
});

app.get("/addjokes", (req, res) => {
    res.render("add-joke")
});

app.post("/addjokes", async (req, res) => {
    console.log(req.body);
    //now that we have the joke values
    //we can use fetch, to send a request to OUR api passing the joke details
    if(req.body.question != "" && req.body.punchline != "" && req.body.category != ""){
        //try to add the joke
        const jokeUrl = "http://localhost:5004/joke/create";

        const bodyString = JSON.stringify(req.body);
        console.log(bodyString)

        const result = await fetch(jokeUrl, {
            method: "POST",
            headers: {
                "content-type" : "application/json"
            },
            body: bodyString
        });

        console.log(await result.json());
    }else{
        //what to do if invalid

    }
    //how do we respond
    res.redirect("/jokes")
});

app.listen(port, () => {
    console.log("express listening on port " + port);
});

